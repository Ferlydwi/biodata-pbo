package biodata;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class Biodata {
    public void namaLengkap(){
        System.out.println("Nama : Ferly Dwi Ilmiarani");
    }
    public void jenisKelamin(){
        System.out.println("Jenis Kelamin : Perempuan");
    }
    public void Ttl(){
        System.out.println("TTL : Pasuruan, 05 Juni 2003");
    }
    public void Umur(){
        System.out.println("Umur : 17 Thn");
    }
    public void Alamat(){
        System.out.println("Alamat : jalan Utomo 2 Pakijangan,Wonorejo");
    }
    public void Hobi(){
        System.out.println("Hobi : Membaca Dan Bercerita");
    }
    public void Kelas(){
        System.out.println("Kelas : XI RPL 1");
    }
    public void Sekolah(){
        System.out.println("Sekolah : SMKN 1 Purwosari");
    }
    
    
}
